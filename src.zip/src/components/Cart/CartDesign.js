// import './CartDesign.css';
// import myimg from '../../img/cart.png';

// function CartDesign(props){
//     return(
//         <div className="outer-cart">
//             <div className="inner-cart">
//                 <div className="cart-img">
//                     <img src={myimg} className="img-cart"/>
//                 </div>
//                 <div className="cart-text">
//                     <h4>Your Cart</h4>
//                 </div>
//                 <div className="cart-counter">
//                     <button className='cart-button'>0</button>
//                 </div>
//             </div>
//         </div>
//     );
// }

// export default CartDesign;